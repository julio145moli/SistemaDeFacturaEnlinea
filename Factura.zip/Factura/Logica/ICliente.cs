﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    interface IClientes
    {
        string Agregar(IClientes cliente);
        string Modificar(IClientes cliente);
        string Buscar(IClientes cliente);
        string exits(IClientes cliente);
        string GetById(IClientes clientes);
        string GetByname(IClientes clientes);
    }
    
}

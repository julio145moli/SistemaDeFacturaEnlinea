﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Inventario:Productos
    {
        public Inventario()
        {
            
        }

        public Inventario(int idproducto, string nombreproducto, string precio,int cantidad, bool estado) : base(idproducto, nombreproducto, precio)
        {
            Cantidad = cantidad;
            Estado = estado;

        }

        public int Cantidad { get; set; }

        public bool Estado { get; set; }


    }
}

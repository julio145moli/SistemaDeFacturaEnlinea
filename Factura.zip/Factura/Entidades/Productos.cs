﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Productos
    {
        public Productos()
        {
            
        }

        public Productos(int idproducto, string nombreproducto, string precio)
        {
            Idproducto = idproducto;
            Nombreproducto = nombreproducto;
            Precio = precio;
        }

        public int Idproducto { get; set; }
        public string Nombreproducto { get; set; }
        public string Precio { get; set;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Cliente:Persona
    {
        public Cliente()
        {
            
        }

        public Cliente(int identificacion, string nombre, string telefono, string dirrecion,string correo) : base(identificacion, nombre, telefono)
        {
            Dirrecion = dirrecion;
            Correo = correo;
        }

        public string Dirrecion { get; set; }

        public string Correo { get; set; }
    }
}

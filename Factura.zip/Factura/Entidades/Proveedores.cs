﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Proveedores:Persona
    {
        public Proveedores()
        {
            
        }

        public Proveedores(int identificacion, string nombre, string telefono) : base(identificacion, nombre, telefono)
        {
        }

        public int Nombreproducto { get; set; }

        public Proveedores(int nombreproducto)
        {
            Nombreproducto = nombreproducto;
        }
    }
}

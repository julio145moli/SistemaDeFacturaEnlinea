﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Facturacion:Productos
    {
        public Facturacion()
        {
            
        }

        public Facturacion(int idproducto, string nombreproducto, string precio,int iva,int numfactura,int total) : base(idproducto, nombreproducto, precio)
        {
            Iva = iva;
            Numfactura = numfactura;
            Total = total;
        }

        public int Iva { get; set; }
        public int Numfactura { get; set; }
        public int Total { get; set; }
    }
}
